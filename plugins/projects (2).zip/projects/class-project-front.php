<?php

class Project_Front{

    public function __construct(){

        // Redirect User if Ip starts with 77.29
        add_action('init', array($this, 'redirect_user_by_checking_ip') );

         //Show Project Data on rchive page
         // add_action('template_redirect', array( $this, 'show_project_data_on_archive_page' ) );
        add_shortcode('coffee',[$this,'get_my_coffee']);
    }
    public function get_my_coffee(){
        ob_start();
        $json_coffe=$this->hs_give_me_coffee();
        $js_obj=json_decode($json_coffe);
        ?>
        <style type="text/css">
            .coffe-link{
                text-decoration: none;
                background-color: brown;
                color: white;
                padding: 20px;
            }
            .flex-center{
                display: flex;
                flex-direction: column;
                gap: 2rem;
                align-items: center;
            }
        </style>
        <div class="flex-center">
            <a class="coffe-link" href="<?php echo $js_obj->data[0]->link; ?>">Here is you Coffe</a>
            <br>
            <img src="<?php echo $js_obj->data[0]->link; ?>">
        </div>
        <?php
        return ob_get_clean();
    }
    public function hs_give_me_coffee() {
        $api_url = 'https://coffee.alexflipnote.dev/random.json';
        $response = wp_remote_get($api_url);

        if (is_wp_error($response)) {
            return json_encode(array('success' => false, 'message' => 'Failed to fetch coffee link: ' . $response->get_error_message()));
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (isset($data['file'])) {
            return json_encode(array('success' => true, 'data' => array(
                array(
                    'id' => uniqid(),
                    'title' => 'Random Coffee',
                    'link' => esc_url($data['file'])
                )
            )));
        } else {
            return json_encode(array('success' => false, 'message' => 'No coffee link found.'));
        }
    }

    public function redirect_user_by_checking_ip(){

        $user_ip = $_SERVER['REMOTE_ADDR'];

        if (strpos($user_ip, '77.29') === 0) {

            wp_redirect('https://www.google.com');
            exit;
        }
    }

    public function show_project_data_on_archive_page() {

        // Check if Single Page is open.
        if (is_singular('project')) {

            include PROJECT_PLUGIN_DIR . 'assets/templates/single-page-template.php';
            exit;
        }
        
        // Check if archive Page is open.
        if (is_post_type_archive('project')) {

            include PROJECT_PLUGIN_DIR . 'assets/templates/archive-page-template.php';
            exit;
        }

    }
}

new Project_Front();