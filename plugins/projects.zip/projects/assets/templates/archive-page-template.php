<?php get_header(); ?>

<h1><?php post_type_archive_title(); ?></h1>

<?php
// Get the current page number
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;

// Define how many posts to show per page
$posts_per_page = 6;

// Fetch the posts using WP_Query
$args = array(
    'post_type'      => 'project', // Replace with your custom post type
    'posts_per_page' => $posts_per_page,
    'paged'          => $paged, // Include pagination
    'post_status'    => 'publish',
);

$query = new WP_Query($args);

// If no posts found
if (!$query->have_posts()) {
    echo '<p>No posts found.</p>';
} else {
    while ($query->have_posts()) {
        $query->the_post();
        
        $post_url = get_permalink();
        $project_title = get_the_title();
        $project_editor_content = get_the_content();
        $project_feature_image_url = get_the_post_thumbnail_url();
        $project_author_name = get_the_author();
        $project_create_date = get_the_date('d-m-Y');

        ?>
        <div style="margin-bottom: 15px; width: 100%; border: 1px solid lightgray; border-radius: 6px; padding: 8px; display: inline-flex;">
            <div style="width: 20%; margin-right: 10px">
                <?php if (!empty($project_feature_image_url)) : ?>
                    <img src="<?php echo esc_url($project_feature_image_url); ?>" width="200px" height="200px">
                <?php endif; ?>
            </div>
            
            <div style="width: 60%; margin-right: 10px">
                <div style="width: 100%">
                    <a href="<?php echo esc_url($post_url); ?>">
                        <h3><?php echo esc_html($project_title); ?></h3>
                    </a>
                </div>

                <div style="width: 100%">
                    <p><?php echo esc_html($project_editor_content); ?></p>
                </div>
            </div>
            
            <div style="width: 20%">
                <div style="width: 100%">
                    <p><b>Written By: </b><?php echo esc_html($project_author_name); ?></p>
                </div>
                
                <div style="width: 100%">
                    <p><b>Created on: </b><?php echo esc_html($project_create_date); ?></p>
                </div>
            </div>
        </div>
        <br>
        <?php
    }
}

// Reset post data
wp_reset_postdata();

// Pagination
$total_pages = $query->max_num_pages; // Get total pages from the query

// Display pagination buttons
if ($total_pages > 1) {
    ?>
    <div class="pagination">
        <?php if ($paged > 1) : ?>
            <a href="<?php echo get_previous_posts_page_link(); ?>" class="prev">« Previous</a>
        <?php endif; ?>
        
        <?php if ($paged < $total_pages) : ?>
            <a href="<?php echo get_next_posts_page_link(); ?>" class="next">Next »</a>
        <?php endif; ?>
    </div>
    <?php
}
get_footer();
