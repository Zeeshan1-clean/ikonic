<?php 

get_header();

$project_post_id = get_the_ID();

$project_post = get_post($project_post_id);

$post_url =  get_permalink($project_post->ID);

$project_title = $project_post->post_title;

$proejct_editor_content = $project_post->post_content;

$project_feature_image_url = get_the_post_thumbnail_url($project_post->ID);

$project_author_id = $project_post->post_author;

$proejct_author_name = get_userdata($project_author_id)->display_name;

$project_create_date = $project_post->post_date_gmt;

$date = new DateTime($project_create_date);

// Show Date in DD-MM-YYYY format.
$project_formatted_date = $date->format('d-m-Y');

?>
<header class="entry-header">
    <h1><?php echo esc_attr($project_title) ?></h1>
</header>

<div class="entry-content">
    <?php
    // Check If Feature image is set or not.
    if( ! empty( $project_feature_image_url ) ){ 
        ?><img src="<?php echo esc_url($project_feature_image_url); ?>" width="800" height="800" class="hentry wp-post-imag"><?php
    }
    ?>
</div>
     
<!-- // Project Content -->
<p><?php echo esc_attr($proejct_editor_content) ?></p>

<p style="float: right">
    <b>Written By: </b><?php echo esc_attr($proejct_author_name) ?>
    <br>
    <b>Created on: </b><?php echo esc_attr($project_formatted_date) ?>
</p>
        
<?php

get_footer();
