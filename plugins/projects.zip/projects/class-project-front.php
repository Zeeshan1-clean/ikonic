<?php

class Project_Front{

    public function __construct(){

        // Redirect User if Ip starts with 77.29
        add_action('init', array($this, 'redirect_user_by_checking_ip') );

         //Show Project Data on rchive page
         // add_action('template_redirect', array( $this, 'show_project_data_on_archive_page' ) );
    }

    public function redirect_user_by_checking_ip(){

        $user_ip = $_SERVER['REMOTE_ADDR'];

        if (strpos($user_ip, '77.29') === 0) {
            
            wp_redirect('https://www.google.com');
            exit;
        }
    }

    public function show_project_data_on_archive_page() {

        // Check if Single Page is open.
        if (is_singular('project')) {

            include PROJECT_PLUGIN_DIR . 'assets/templates/single-page-template.php';
            exit;
        }
        
        // Check if archive Page is open.
        if (is_post_type_archive('project')) {

            include PROJECT_PLUGIN_DIR . 'assets/templates/archive-page-template.php';
            exit;
        }
    
    }
}

new Project_Front();